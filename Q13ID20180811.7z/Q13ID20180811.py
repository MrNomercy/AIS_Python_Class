## student: Rithea cheng
## ID: 20180811
## class:7.103
## date: 17 oct 2018
## description: Q13 midterm test

# assign variable called num_input to get user input
num_input = int(input("Please enter a number: "))
mylist = []

# creat function called find_factor
def find_factor(num_input):
	for i in range(1,num_input+1):
		if num_input%i == 0:
			mylist.append(i)
		else:
			pass
			
# using the function
find_factor(num_input)
print("The factors of",num_input,"are given in the list below: ")
print(mylist)
