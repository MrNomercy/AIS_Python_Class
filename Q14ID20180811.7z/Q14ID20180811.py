## ID: 20180811
## class:7.103
## date: 17 oct 2018
## description: Q13 midterm test

my_count = 1
my_attempt = 6
special_sym = ["@","#","$","%","^","&","*"]
my_digits = ["0","1","2","3","4","5","6","7","8","9"]

def check_special(myinput):
	mylist = list(myinput)
	for i in special_sym:
		if i in mylist:
			return True
		else:
			pass

def check_digits(myinput):
	mylist = list(myinput)
	for i in my_digits:
		if i in mylist:
			return True
		else:
			pass


while my_count <= my_attempt:
	pass_input = input("Please insert a password: ")

	if check_special(pass_input) != True:
		print("The password should contain at least one special characters{@,#,$.%,^,&,*}")
	elif len(pass_input)<5 or len(pass_input)>10:
		print("Password should between 5 to 10 characters")
	elif check_digits(pass_input) and check_special(pass_input):
		print("This is a valid password.")
		break
	elif pass_input.isalnum() is False:
		print("The password must be a mixture of characters and digits.")
	else:
		pass
	my_count += 1

	
		